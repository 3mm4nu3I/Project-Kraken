# Changelog

All notable changes to **The Grand Formula of Brain Happiness** project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.3.0] - 2026-10-11
### Added
- **Dynamic Synaptic Intensity Visualization**:
  - Live intensity calculation for all 10 neural pathways based on real-time variable values.
  - Animated 3D axon fiber lines with opacity and thickness dynamically scaling with traffic intensity.
  - Variable-velocity synaptic light packets racing faster during hyperactive surges.
  - Concentric node shockwave auras pulsing at frequencies proportional to incoming synaptic traffic.
  - Interactive Synaptic Intensity HUD with real-time meter gauges and surge filters.
- **Academic Research Paper Integration (`PAPER.md`)**:
  - Full scientific draft paper titled *"The Grand Unified Formula of Human Cranial Happiness"*.
  - In-app interactive Academic Paper Reader modal with section navigation and markdown export.
- **Backup & Cloud Sync Hub**:
  - Full state snapshot backup download (`.json`) and snapshot restore file import.
  - Automated export configurations for Google Drive, Microsoft OneDrive, and GitHub repositories.
- **Interactive Changelog Viewer**: In-app version history modal.

---

## [1.2.0] - 2026-10-11
### Added
- **Realistic 3D Human Brain Model**:
  - Parametric anatomical brain geometry with gyri and sulci convolutions.
  - Bilateral cerebral hemispheres, cerebellum, and brainstem.
- **10 Distinct Colored Functional Sections**:
  1. Prefrontal Cortex (`#06B6D4` - Laser Cyan)
  2. Motor & Premotor Cortex (`#A855F7` - Electric Violet)
  3. Somatosensory Cortex (`#F59E0B` - Amber Gold)
  4. Parietal Association Cortex (`#14B8A6` - Teal Green)
  5. Occipital Visual Cortex (`#6366F1` - Royal Indigo)
  6. Auditory & Temporal Cortex (`#FB923C` - Coral Orange)
  7. Nucleus Accumbens (`#10B981` - Emerald Jade)
  8. Amygdala Sentinel (`#EF4444` - Flame Red)
  9. Insula & Hypothalamus Core (`#EC4899` - Hot Pink)
  10. Cerebellum & Brainstem (`#84CC16` - Lime Green)
- **Active 3D Connectome Synaptic Pathways**:
  - Curved 3D Catmull-Rom streamlines interconnecting the 10 sections.
  - Flowing photon action-potential packets with "Fire Impulse" manual stimulation trigger.
- **Anatomical Camera Presets**:
  - 3D Orbit, Sagittal Profile, Coronal Frontal, Axial Dorsal, and Ventral Base perspectives.

---

## [1.1.0] - 2026-10-07
### Added
- **Bespoke Variable Synthesizer**: Create custom illogical quirks and firmware bugs dynamically injected into the formula.
- **Interactive Paradox Laboratory**: Edge-case testing for the *Warm Sock vs. Existential Dread Ratio*, the *Hangry Inversion Point*, and the *94-Browser Tab Cognitive RAM Leak*.
- **Personalized Theorem Treatise & Export**: Formal certificate generation with LaTeX source and download.
- **Neuro-Acoustic Synthesizer**: Web Audio binaural drone and harmonic pings modulated by the happiness index.

---

## [1.0.0] - 2026-10-07
### Added
- **The Grand Unified Happiness Formula ($\mathcal{H}_{\text{brain}}$)**:
  - Canonical and expanded KaTeX formula renderer.
  - 36+ biological, psychological, illogical, and faulty variables.
  - Live marginal partial derivatives ($\partial \mathcal{H}/\partial v$).
- **Curated Scenario Presets**:
  - *Calibrated Baseline*, *Canceled Friday Night Nirvana*, *3 AM Tab Spiral*, *Flow Coding*, *Hangry Meltdown*, *Golden Dog Park*.
